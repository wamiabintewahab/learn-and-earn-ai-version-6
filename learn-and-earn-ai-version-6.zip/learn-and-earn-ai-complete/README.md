# Learn and Earn AI — Version 6 starter

A responsive, dark-themed beginner coding platform with learning paths, project pages, a JavaScript playground, Wamia AI chat UI, and local learning preferences.

## Run locally

Requirements: Node.js 18 or newer.

```bash
npm start
```

Open http://localhost:3000. Check `/api/health` for service configuration status.

## Configure Wamia AI

The Wamia chat endpoint uses an OpenAI-compatible Chat Completions API. Configure these **server environment variables** with values from an AI provider:

- `WAMIA_API_URL` — full chat-completions endpoint URL
- `WAMIA_API_KEY` — secret key; keep it server-side and never commit it
- `WAMIA_MODEL` — model identifier supported by your provider

Restart the server after setting them. If they are missing, Wamia reports that the AI service is not connected instead of pretending to answer. Exact provider URL/model and account setup depend on the chosen provider.

## Important limitations before public launch

- Login, signup, email verification, password recovery, and cloud database are **not yet connected**. Forms must not be treated as real authentication.
- Settings are saved only in the current browser using local storage.
- The playground currently executes JavaScript with `new Function` in the page context. This is **not safe for arbitrary public code** and must be replaced with an isolated execution sandbox before accepting untrusted code. Python/Java and other runtimes are not connected.
- Video page content is a learning-page scaffold; live streaming/video hosting is not connected.
- The Wamia endpoint is a minimal integration scaffold. Before production, add rate limiting, abuse controls, provider-specific validation, monitoring, and deployment secrets. Do not expose API keys in frontend files or GitHub.
- GitHub Pages can host static files but cannot run this Node.js server or the Wamia endpoint. Deploy the backend to a Node-capable host and configure the environment variables there.

This is a tested starter, not a claim that every production service is already live or that software is guaranteed bug-free.
